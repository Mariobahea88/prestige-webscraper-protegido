import os
import shutil
import openpyxl
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import re
from bs4 import BeautifulSoup

from config import PESQUISA, NUM_RESULTADOS

# Caminho do chromedriver local (mesma pasta do script)
CHROMEDRIVER_PATH = os.path.join(os.path.dirname(__file__), 'chromedriver.exe')

# Configuração do Selenium
options = Options()
options.add_argument("--start-maximized")
service = Service(CHROMEDRIVER_PATH)
driver = webdriver.Chrome(service=service, options=options)
wait = WebDriverWait(driver, 10)

# Iniciando a pesquisa
query = PESQUISA.replace(" ", "+")
driver.get(f"https://www.google.com/maps/search/{query}")
time.sleep(5)

# Função para rolar a página
def scroll_para_carregar(total_desejado):
    scrollable_div = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div[role="feed"]')))
    tentativas = 0
    while len(driver.find_elements(By.CSS_SELECTOR, 'a.hfpxzc')) < total_desejado and tentativas < 15:
        driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", scrollable_div)
        time.sleep(2)
        tentativas += 1

scroll_para_carregar(NUM_RESULTADOS)

# Coletando links
links = []
results = driver.find_elements(By.CSS_SELECTOR, 'a.hfpxzc')
for result in results:
    href = result.get_attribute('href')
    if '/place/' in href and href not in links:
        links.append(href)

# Extraindo dados
dados = []
for i, link in enumerate(links[:NUM_RESULTADOS]):
    print(f"🔎 Coletando dados {i+1}/{NUM_RESULTADOS}...")
    driver.get(link)
    time.sleep(5)

    soup = BeautifulSoup(driver.page_source, 'html.parser')

    try:
        nome = driver.find_element(By.XPATH, '//h1[contains(@class, "DUwDvf")]').text
    except: nome = ""

    try:
        categoria = driver.find_element(By.CLASS_NAME, "DkEaL").text
    except: categoria = ""

    endereco = ""
    try:
        endereco_el = driver.find_element(By.XPATH, '//button[contains(@data-item-id, "address")]')
        endereco = endereco_el.text
    except: pass

    website = ""
    try:
        site_el = driver.find_element(By.XPATH, '//a[contains(@data-item-id, "authority")]')
        website = site_el.get_attribute('href')
    except: pass

    telefone = ""
    try:
        tel_el = driver.find_element(By.XPATH, '//button[contains(@data-item-id, "phone")]')
        telefone = re.sub(r'[^\d\-\(\)\s]', '', tel_el.text.strip())
    except:
        html_text = soup.get_text()
        telefones = re.findall(r'\(?\d{2}\)?\s?\d{4,5}-\d{4}', html_text)
        if telefones:
            telefone = re.sub(r'[^\d\-\(\)\s]', '', telefones[0])

    dados.append([nome, categoria, endereco, telefone, website])

# Finalizando a navegação
driver.quit()

# Salvando os dados em uma planilha Excel
try:
    # Definindo o caminho do arquivo temporário
    temp_file_path = os.path.join(os.path.dirname(__file__), "resultado_temp.xlsx")
    
    # Criando a planilha
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Resultados"
    ws.append(["Nome", "Categoria", "Endereço", "Telefone", "Website"])

    # Adicionando as linhas
    for linha in dados:
        ws.append(linha)

    # Salvando o arquivo temporário
    wb.save(temp_file_path)
    print(f"✅ Planilha salva com sucesso em: {temp_file_path}")

    # Movendo o arquivo para o diretório onde o script foi executado
    final_file_path = os.path.join(os.path.dirname(__file__), "resultado.xlsx")
    shutil.move(temp_file_path, final_file_path)
    print(f"✅ Planilha movida para: {final_file_path}")

except Exception as e:
    print(f"❌ Erro ao salvar ou mover a planilha: {e}")
